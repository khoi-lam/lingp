# Chi Tiết Bản Cập Nhật Hệ Thống Chatbot AI (Bookstore)

Bản cập nhật này nâng cấp toàn diện hệ thống Chatbot từ tìm kiếm từ khóa cơ bản sang Trợ lý ảo thông minh sử dụng Trí tuệ nhân tạo (AI) với khả năng tư vấn chuyên sâu.

## 📂 Danh sách file thay đổi
- `client/src/components/ChatBubble.jsx`: Logic hiển thị, tích hợp phân tích Markdown.
- `client/src/components/ChatBubble.css`: Giao diện cao cấp, hỗ trợ typography Markdown.
- `server/controllers/chatController.js`: Bộ não AI mới, xử lý tìm kiếm Semantic và Fallback đa tầng.
- `server/sync_embeddings.js`: Script đồng bộ hóa dữ liệu Vector cho tìm kiếm AI.

## 🚀 Các tính năng cốt lõi

### 1. Hệ thống Fallback Đa Tầng (Indestructible AI)
Để đảm bảo chatbot không bao giờ bị "chết" hay phản hồi lỗi hệ thống, chúng tôi đã triển khai cơ chế dự phòng tự động:
- **Ưu tiên 1:** Llama-3-8B (Thông minh nhất).
- **Dự phòng 1:** Mistral-7B (Ổn định).
- **Dự phòng 2:** Phi-3-mini (Tốc độ cao).
- Tự động thử lại (Retry) 2 lần nếu API gặp lỗi quá tải (429/503).

### 2. Tìm kiếm Semantic (AI Understanding)
Chatbot không còn tìm theo từ khóa chính xác. Nó hiểu **ý nghĩa** của câu hỏi.
- Ví dụ: Hỏi "sách về coding" sẽ tự động tìm thấy các sách "lập trình" dù không trùng chữ.
- Sử dụng Vector Embeddings (BGE-Small-v1.5) để so khớp độ tương đồng.

### 3. Phản hồi Cấu trúc 3 Phần
Mọi câu trả lời của AI giờ đây đều được định dạng chuyên nghiệp:
1. **Mô tả thể loại:** Giải thích kiến thức về chủ đề khách hỏi.
2. **Top 5 Thế giới:** Gợi ý những đầu sách kinh điển toàn cầu.
3. **Tại cửa hàng:** Liệt kê các sách thực tế đang có sẵn trong kho.

### 4. Giao diện Premium & Markdown
- Header Gradient tím-xanh hiện đại.
- Hiển thị Markdown: Tự động in đậm (bold), ngắt dòng, giúp đoạn hội thoại dễ đọc hơn.
- Hiển thị thẻ sách (Book Cards) trực quan kèm giá và mô tả.

## 🛠 Hướng dẫn áp dụng

1. **Cập nhật Database:**
   - Đảm bảo các cuốn sách có mô tả chính xác.
   - Chạy script đồng bộ vector: `node server/sync_embeddings.js`.

2. **Biến môi trường (.env):**
   - Đảm bảo đã có `HF_API_KEY` (Token từ Hugging Face).

3. **Khởi động:**
   - Restart lại Backend để nạp logic mới.
   - F5 Client để cập nhật giao diện Markdown.

---
*Bản quyền phát triển bởi Antigravity AI Team.*
